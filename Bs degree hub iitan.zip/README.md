# BS Degree Hub IITAN

A responsive student study hub for IITAN BS degree learners. The app runs as a static website and stores demo accounts, quizzes, notes, assignments, community posts, messages, and videos in the browser's local storage.

## Run

Open `index.html` in a modern browser. No build tools or dependencies are required.

## Features

- Sign-in and account creation screens
- Home dashboard and subject progress cards
- Student-created practice quizzes with immediate answer explanations and scores
- Notes library with local file uploads
- Assignment deadlines, file submissions, and submission status tracking
- Community posts, likes, comments, and sharing
- Direct-message interface
- Study video/reel library with local video uploads
- Responsive layouts for desktop and mobile

## Demo limitations

This is a front-end-only project. Account credentials and content are stored in the current browser and are not synced between devices. Uploaded files are kept locally; files larger than 3 MB are not accepted. Production authentication, shared content, real-time messaging, instructor grading, and cloud file storage require a backend service.
