/* BS Degree Hub IITAN — student community and study tools */
(() => {
  'use strict';
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const STORE = 'bs-degree-hub-iitan-v1';
  const today = new Date();
  const iso = (offset = 0) => { const d = new Date(); d.setDate(d.getDate() + offset); return d.toISOString(); };
  const formatDate = (date) => new Date(date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  const escapeHtml = (value = '') => String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const initials = name => (name || 'Student').trim().split(/\s+/).slice(0, 2).map(x => x[0]).join('').toUpperCase();
  const subjects = ['Mathematics', 'Statistics', 'Programming', 'English', 'Data Science', 'Economics'];
  const initialData = () => ({
    user: null,
    quizzes: [
      { id: 'q1', title: 'Limits & continuity — quick check', subject: 'Mathematics', difficulty: 'Easy', description: 'Build confidence with the foundations of limits and continuity.', creator: 'Riya Mehta', questions: [{ prompt: 'What is the limit of (x² − 1)/(x − 1) as x approaches 1?', options: ['0', '1', '2', 'Does not exist'], answer: 2 }, { prompt: 'A function is continuous at x = a when:', options: ['Only f(a) exists', 'The limit exists and equals f(a)', 'The derivative is zero', 'The function is increasing'], answer: 1 }, { prompt: 'lim (sin x)/x as x approaches 0 equals:', options: ['0', '1', '−1', 'Undefined'], answer: 1 }], attempts: 18, createdAt: iso(-2) },
      { id: 'q2', title: 'Probability & distributions', subject: 'Statistics', difficulty: 'Medium', description: 'Test your understanding of probability rules and random variables.', creator: 'Arjun Nair', questions: [{ prompt: 'The probability of a certain event is:', options: ['0', '0.5', '1', 'Cannot be known'], answer: 2 }, { prompt: 'For independent events A and B:', options: ['P(A∩B)=P(A)+P(B)', 'P(A∩B)=P(A)P(B)', 'P(A|B)=0', 'P(A)=P(B)'], answer: 1 }, { prompt: 'The mean of a fair six-sided die roll is:', options: ['3', '3.5', '4', '6'], answer: 1 }], attempts: 24, createdAt: iso(-1) },
      { id: 'q3', title: 'Python basics: lists & loops', subject: 'Programming', difficulty: 'Easy', description: 'A friendly warm-up on Python lists, indexing, and loops.', creator: 'Neel Shah', questions: [{ prompt: 'What is the index of the first item in a Python list?', options: ['0', '1', '−1', 'It depends'], answer: 0 }, { prompt: 'What does len([2, 4, 6]) return?', options: ['2', '3', '6', '12'], answer: 1 }, { prompt: 'Which keyword starts a loop over a sequence?', options: ['while', 'loop', 'for', 'repeat'], answer: 2 }], attempts: 31, createdAt: iso(-3) },
      { id: 'q4', title: 'Descriptive statistics', subject: 'Statistics', difficulty: 'Hard', description: 'Practice interpreting spread, variance, and summary measures.', creator: 'Maya Iyer', questions: [{ prompt: 'The standard deviation is the square root of:', options: ['Mean', 'Variance', 'Median', 'Range'], answer: 1 }, { prompt: 'Which measure is least affected by an extreme outlier?', options: ['Mean', 'Range', 'Median', 'Variance'], answer: 2 }], attempts: 12, createdAt: iso(-4) },
      { id: 'q5', title: 'Functions and graphs', subject: 'Mathematics', difficulty: 'Medium', description: 'Read transformations and key features of common functions.', creator: 'Riya Mehta', questions: [{ prompt: 'The graph of y = f(x) + 3 shifts the graph:', options: ['3 units left', '3 units right', '3 units up', '3 units down'], answer: 2 }, { prompt: 'The domain of √x for real values is:', options: ['x < 0', 'x ≥ 0', 'All real x', 'x > 1'], answer: 1 }], attempts: 9, createdAt: iso(-5) }
    ],
    notes: [
      { id: 'n1', title: 'Week 4 — Probability essentials', subject: 'Statistics', description: 'A clean summary of conditional probability, Bayes’ theorem, and worked examples.', creator: 'Ananya Rao', fileName: 'probability-week-4.pdf', fileData: '', cover: 'yellow', createdAt: iso(-1) },
      { id: 'n2', title: 'Python cheat sheet', subject: 'Programming', description: 'Quick reference for list methods, loops, and common built-in functions.', creator: 'Kabir Singh', fileName: 'python-cheatsheet.pdf', fileData: '', cover: 'blue', createdAt: iso(-2) },
      { id: 'n3', title: 'Limits: solved examples', subject: 'Mathematics', description: 'Step-by-step solutions to the most common limit question patterns.', creator: 'Riya Mehta', fileName: 'limits-examples.pdf', fileData: '', cover: '', createdAt: iso(-3) },
      { id: 'n4', title: 'Academic writing notes', subject: 'English', description: 'Structure, citations, and useful checklists for clear academic writing.', creator: 'Dev Patel', fileName: 'writing-notes.pdf', fileData: '', cover: 'pink', createdAt: iso(-6) }
    ],
    assignments: [
      { id: 'a1', title: 'Problem Set 03: Differential calculus', subject: 'Mathematics', due: iso(2), description: 'Submit solutions for questions 1–8. Show all working clearly.', status: 'Open', fileName: '', fileData: '', creator: 'Course team' },
      { id: 'a2', title: 'Statistics lab: sampling & estimation', subject: 'Statistics', due: iso(4), description: 'Complete the worksheet and upload your answers as one PDF.', status: 'Open', fileName: '', fileData: '', creator: 'Course team' },
      { id: 'a3', title: 'Python practice: data cleaning', subject: 'Programming', due: iso(-1), description: 'Write a short script to clean and summarize the provided data.', status: 'Submitted', fileName: 'data-cleaning.py', fileData: '', creator: 'Course team' }
    ],
    posts: [
      { id: 'p1', author: 'Aarav Kulkarni', body: 'Anyone up for a quick study session on conditional probability this evening? I made a one-page summary too — happy to share it!', subject: 'Statistics', attachment: '', createdAt: iso(-1), likes: 8, liked: false, comments: [{ author: 'Meera Joshi', text: 'Count me in! The library at 6?' }] },
      { id: 'p2', author: 'Ishita Verma', body: 'Tiny reminder: the best way I found to get comfortable with limits is to do a few different types every day instead of cramming. You’ve got this 🌱', subject: 'Mathematics', attachment: '', createdAt: iso(-2), likes: 14, liked: false, comments: [] },
      { id: 'p3', author: 'Kabir Singh', body: 'Just uploaded a Python list-comprehension cheat sheet to the notes library. Hope it saves someone a few minutes!', subject: 'Programming', attachment: 'Python cheat sheet', createdAt: iso(-3), likes: 6, liked: false, comments: [] }
    ],
    videos: [
      { id: 'v1', title: 'One-minute trick for tricky limits', subject: 'Mathematics', creator: 'Riya Mehta', description: 'A quick way to spot factorisation opportunities.', symbol: '∫', likes: 32, createdAt: iso(-1), fileName: '', fileData: '' },
      { id: 'v2', title: 'Python list comprehensions, simply', subject: 'Programming', creator: 'Neel Shah', description: 'Turn a few lines into one readable expression.', symbol: '⌘', likes: 27, createdAt: iso(-2), fileName: '', fileData: '' },
      { id: 'v3', title: 'How I organise my study notes', subject: 'Study tips', creator: 'Maya Iyer', description: 'A simple system for revision that actually sticks.', symbol: '✳', likes: 41, createdAt: iso(-4), fileName: '', fileData: '' }
    ],
    chats: {},
    quizResults: [],
    streak: 1
  });
  let data;
  try { data = JSON.parse(localStorage.getItem(STORE)) || initialData(); } catch (_) { data = initialData(); }
  const save = () => localStorage.setItem(STORE, JSON.stringify(data));
  const persist = (notify, message) => { save(); renderAll(); if (notify) toast(message); };
  let activeView = 'home';
  let activeQuizFilter = 'All subjects';
  let activeNoteFilter = 'All subjects';
  let activeChat = 'Meera Joshi';
  let authMode = 'signin';
  let toastTimer;
  let currentQuiz = null;
  let selectedFiles = {};
  const people = [
    { name: 'Meera Joshi', initials: 'MJ', color: 'alt', preview: 'That makes sense, thank you!' },
    { name: 'Rohan Das', initials: 'RD', color: '', preview: 'Are we meeting at 5?' },
    { name: 'Aanya Bose', initials: 'AB', color: 'alt2', preview: 'Shared my notes with you' }
  ];
  function toast(message) { const el = $('#toast'); el.textContent = message; el.classList.add('show'); clearTimeout(toastTimer); toastTimer = setTimeout(() => el.classList.remove('show'), 2600); }
  function avatar(name, cls = '') { return `<span class="person-avatar ${cls}">${escapeHtml(initials(name))}</span>`; }
  function empty(icon, heading, message, action = '') { return `<div class="empty-state"><div class="empty-icon">${icon}</div><h3>${heading}</h3><p>${message}</p>${action}</div>`; }
  function authRender() {
    const user = data.user;
    if (user) { $('#authScreen').hidden = true; $('#app').hidden = false; $('#sidebarUserName').textContent = user.name; $('#sidebarAvatar').textContent = initials(user.name); $('#topAvatar').textContent = initials(user.name); }
    else { $('#authScreen').hidden = false; $('#app').hidden = true; }
    $('#authError').textContent = '';
  }
  function setAuthMode(mode) {
    authMode = mode; const signup = mode === 'signup';
    $('#authTitle').textContent = signup ? 'Make this yours.' : 'Good to see you.';
    $('#authSubtitle').textContent = signup ? 'Create your account and find your people.' : 'Sign in to pick up where you left off.';
    $('#nameField').hidden = !signup; $('#authName').required = signup;
    $('#authSubmitText').textContent = signup ? 'Create my account' : 'Sign in';
    $('#switchPrompt').textContent = signup ? 'Already have an account?' : 'New to the hub?';
    $('#authToggle').textContent = signup ? 'Sign in instead' : 'Create an account';
    $('#forgotButton').hidden = signup; $('#authPassword').autocomplete = signup ? 'new-password' : 'current-password';
    $('#authError').textContent = '';
  }
  function go(view) {
    activeView = view; $$('.nav-item').forEach(b => b.classList.toggle('active', b.dataset.view === view));
    $$('.view').forEach(v => v.classList.toggle('active', v.id === `view-${view}`));
    const labels = { home: 'Home', quizzes: 'Practice quizzes', notes: 'Notes library', assignments: 'Assignments', community: 'Community', reels: 'Reels & videos' };
    $('#currentSection').textContent = labels[view] || 'Home'; $('#sidebar').classList.remove('open'); window.scrollTo({ top: 0, behavior: 'smooth' });
    if (view === 'community') renderChats();
  }
  function renderHome() {
    const name = (data.user?.name || 'Student').split(' ')[0];
    const openAssignments = data.assignments.filter(a => a.status !== 'Submitted');
    const subjectsMarkup = subjects.slice(0, 6).map((s, i) => {
      const icons = ['∑', '◉', '⌘', 'Aa', '⌁', '↗']; const colors = ['#edf3e8', '#f5efe0', '#e9eff5', '#f4eae6', '#edf1e8', '#e8f0ee'];
      const done = [62, 44, 71, 33, 48, 27][i];
      return `<div class="subject-card"><span class="subject-arrow">↗</span><span class="subject-icon" style="background:${colors[i]};color:#638168">${icons[i]}</span><h4>${s}</h4><p>${Math.round(done / 12)} resources · ${done}% explored</p><div class="progress-track"><div class="progress-fill" style="width:${done}%"></div></div></div>`;
    }).join('');
    const activities = [
      { icon: '▤', title: 'New quiz: Limits & continuity', detail: 'Mathematics · 3 questions', trail: '2h ago' },
      { icon: '▧', title: 'Fresh notes from Ananya', detail: 'Probability essentials', trail: '5h ago' },
      { icon: '▷', title: 'A new study reel is up', detail: 'Python list comprehensions', trail: '1d ago' }
    ].map(x => `<div class="activity-item"><span class="activity-icon">${x.icon}</span><span class="activity-copy"><b>${x.title}</b><small>${x.detail}</small></span><span class="activity-trail">${x.trail}</span></div>`).join('');
    const assignmentRows = openAssignments.slice(0, 2).map(a => `<div class="assignment-row"><span class="activity-icon">☑</span><span class="assignment-copy"><b>${escapeHtml(a.title)}</b><small>${escapeHtml(a.subject)} · due ${formatDate(a.due)}</small></span><span class="due-pill">${Math.ceil((new Date(a.due) - today) / 86400000) <= 1 ? 'Due soon' : 'Upcoming'}</span></div>`).join('') || '<p class="muted-copy">You’re all caught up — nice work!</p>';
    $('#view-home').innerHTML = `<div class="welcome-row"><div><div class="eyebrow-dark">MONDAY, ${today.toLocaleDateString(undefined, { month: 'long', day: 'numeric' }).toUpperCase()}</div><h1>Hey ${escapeHtml(name)}, good to have you here <span>✳</span></h1><p>Your next small step is waiting whenever you are.</p></div><div class="date-label">${today.toLocaleDateString(undefined, { weekday: 'long', month: 'long', day: 'numeric' })}</div></div>
      <div class="hero-banner"><div class="hero-text"><div class="eyebrow">A LITTLE PROGRESS GOES A LONG WAY</div><h2>Make today a study day.</h2><p>Pick up a quick quiz, share what you know, or find a study buddy.</p><button class="button" data-go="quizzes">Explore practice quizzes <span>→</span></button></div><div class="hero-side-note">YOUR LEARNING STREAK<strong>🔥 ${data.streak || 1} day${data.streak === 1 ? '' : 's'}</strong></div></div>
      <div class="dashboard-grid"><div class="section-card"><div class="section-header"><h3>Your subjects</h3><button class="text-button" data-go="notes">Browse notes →</button></div><div class="subject-grid">${subjectsMarkup}</div></div><div class="section-card"><div class="section-header"><h3>Happening around you</h3><button class="text-button" data-go="community">See all →</button></div><div class="activity-list">${activities}</div></div></div>
      <div class="lower-grid"><div class="section-card"><div class="section-header"><h3>Coming up</h3><button class="text-button" data-go="assignments">All assignments →</button></div>${assignmentRows}</div><div class="section-card"><div class="section-header"><h3>Your study circle</h3><button class="text-button" data-go="community">Open chats →</button></div>${people.map((p, i) => `<div class="people-row">${avatar(p.name, p.color)}<span class="person-copy"><b>${p.name}</b><small>${i === 0 ? 'Online now' : 'IITAN student'}</small></span>${i === 0 ? '<i class="online-dot"></i>' : ''}</div>`).join('')}</div></div>`;
  }
  function renderQuizzes() {
    const query = ($('#quizSearch')?.value || '').toLowerCase();
    const list = data.quizzes.filter(q => (activeQuizFilter === 'All subjects' || q.subject === activeQuizFilter) && `${q.title} ${q.subject} ${q.description}`.toLowerCase().includes(query));
    const cards = list.map(q => `<article class="quiz-card"><div class="card-topline"><span class="subject-tag">${escapeHtml(q.subject)}</span><span class="difficulty">${escapeHtml(q.difficulty || 'Medium')} · ✦</span></div><h3>${escapeHtml(q.title)}</h3><p>${escapeHtml(q.description || '')}</p><div class="card-meta"><span>☷ ${q.questions.length} questions</span><span>◷ ${q.attempts || 0} attempts</span></div><div class="card-footer"><span class="creator"><span class="tiny-avatar">${initials(q.creator)}</span>${escapeHtml(q.creator || 'Student')}</span><button class="button button-secondary" data-action="start-quiz" data-id="${q.id}">Start quiz →</button></div></article>`).join('');
    $('#view-quizzes').innerHTML = `<div class="page-heading"><div><div class="eyebrow-dark">LEARN BY DOING</div><h1>Practice quizzes</h1><p>Try a quick quiz, check what you know, and learn as you go.</p></div><div class="heading-actions"><button class="button button-primary" data-action="create-quiz">＋ Create a quiz</button></div></div><div class="filter-row">${['All subjects', ...subjects].map(s => `<button class="filter-chip ${activeQuizFilter === s ? 'active' : ''}" data-action="quiz-filter" data-value="${s}">${s}</button>`).join('')}<span class="filter-spacer"></span><input class="filter-search" id="quizSearch" placeholder="⌕  Find a quiz..." value="${escapeHtml($('#quizSearch')?.value || '')}" /></div><div class="quiz-grid">${cards || empty('▤', 'No quizzes found', 'Try a different subject or create the first quiz.')}</div>`;
  }
  function renderNotes() {
    const query = ($('#noteSearch')?.value || '').toLowerCase();
    const list = data.notes.filter(n => (activeNoteFilter === 'All subjects' || n.subject === activeNoteFilter) && `${n.title} ${n.subject} ${n.description}`.toLowerCase().includes(query));
    const cards = list.map(n => `<article class="note-card"><div class="note-cover ${escapeHtml(n.cover || '')}"><strong>${escapeHtml(n.subject)}</strong><span class="cover-symbol">${n.subject === 'Mathematics' ? '∑' : n.subject === 'Programming' ? '⌘' : '▧'}</span></div><div class="note-body"><div class="card-topline"><span class="subject-tag">${escapeHtml(n.fileName || 'Study notes')}</span><span class="creator">${escapeHtml(formatDate(n.createdAt))}</span></div><h3>${escapeHtml(n.title)}</h3><p>${escapeHtml(n.description || 'Shared study resource from your IITAN community.')}</p><div class="card-footer"><span class="creator"><span class="tiny-avatar">${initials(n.creator)}</span>${escapeHtml(n.creator || 'Student')}</span><button class="note-download" data-action="open-note" data-id="${n.id}">Open resource ↗</button></div></div></article>`).join('');
    $('#view-notes').innerHTML = `<div class="page-heading"><div><div class="eyebrow-dark">SHARE WHAT YOU KNOW</div><h1>Notes library</h1><p>Find a helpful summary or add something that helped you.</p></div><div class="heading-actions"><button class="button button-primary" data-action="add-note">＋ Upload notes</button></div></div><div class="filter-row">${['All subjects', ...subjects].map(s => `<button class="filter-chip ${activeNoteFilter === s ? 'active' : ''}" data-action="note-filter" data-value="${s}">${s}</button>`).join('')}<span class="filter-spacer"></span><input class="filter-search" id="noteSearch" placeholder="⌕  Search notes..." value="${escapeHtml($('#noteSearch')?.value || '')}" /></div><div class="notes-grid">${cards || empty('▧', 'No notes just yet', 'Share your first study resource with the community.')}</div>`;
  }
  function renderAssignments() {
    const sorted = [...data.assignments].sort((a, b) => new Date(a.due) - new Date(b.due));
    const cards = sorted.map(a => { const done = a.status === 'Submitted'; return `<article class="assignment-full-card"><span class="assignment-status-icon ${done ? 'done' : ''}">${done ? '✓' : '☑'}</span><div class="assignment-detail"><h3>${escapeHtml(a.title)}</h3><p>${escapeHtml(a.subject)} · ${escapeHtml(a.description || '')}</p></div><div class="assignment-right"><span class="status-badge ${done ? 'done' : ''}">${done ? 'Submitted' : `Due ${formatDate(a.due)}`}</span>${done ? `<button class="button button-plain" data-action="view-submission" data-id="${a.id}">${escapeHtml(a.fileName || 'View submission')}</button>` : `<button class="button button-secondary" data-action="submit-assignment" data-id="${a.id}">Submit work →</button>`}</div></article>`; }).join('');
    $('#view-assignments').innerHTML = `<div class="page-heading"><div><div class="eyebrow-dark">KEEP YOUR MOMENTUM</div><h1>Assignments</h1><p>Keep track of what’s due and submit your work in one place.</p></div><div class="heading-actions"><button class="button button-primary" data-action="create-assignment">＋ Add assignment</button></div></div><div class="filter-row"><span class="filter-chip active">${data.assignments.filter(a => a.status !== 'Submitted').length} to do</span><span class="filter-chip">${data.assignments.filter(a => a.status === 'Submitted').length} submitted</span></div><div class="assignment-list">${cards || empty('☑', 'You’re all caught up', 'Add an assignment whenever you need a reminder.')}</div>`;
  }
  function renderPosts() {
    return [...data.posts].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).map(p => `<article class="post-card"><div class="post-author">${avatar(p.author)}<span class="post-author-meta"><b>${escapeHtml(p.author)}</b><small>${escapeHtml(p.subject || 'IITAN student')} · ${formatDate(p.createdAt)}</small></span><button class="post-more" aria-label="More options">···</button></div><p class="post-body">${escapeHtml(p.body)}</p>${p.attachment ? `<div class="post-attachment"><span>▧ &nbsp;${escapeHtml(p.attachment)}</span><span>Shared resource ↗</span></div>` : ''}<div class="post-actions"><button class="post-action ${p.liked ? 'liked' : ''}" data-action="like-post" data-id="${p.id}"><span>${p.liked ? '♥' : '♡'}</span>${p.likes} likes</button><button class="post-action" data-action="comment-post" data-id="${p.id}"><span>◯</span>${p.comments?.length || 0} comments</button><button class="post-action" data-action="share-post" data-id="${p.id}"><span>↗</span>Share</button></div></article>`).join('');
  }
  function renderChats() {
    if (!$('#chatList')) return;
    const current = people.find(p => p.name === activeChat) || people[0];
    const messages = data.chats[activeChat] || [{ text: 'Hey! How is your week going?', mine: false, time: '10:12' }, { text: 'Pretty good! I’m working through the probability notes now.', mine: true, time: '10:14' }, { text: 'That makes sense, thank you!', mine: false, time: '10:16' }];
    $('#chatList').innerHTML = people.map(p => `<div class="chat-person ${p.name === activeChat ? 'active' : ''}" data-action="select-chat" data-name="${p.name}">${avatar(p.name, p.color)}<span class="chat-person-copy"><b>${p.name}</b><small>${escapeHtml((data.chats[p.name] || []).slice(-1)[0]?.text || p.preview)}</small></span></div>`).join('');
    $('#chatMessages').innerHTML = `<div class="chat-date">TODAY</div>${messages.map(m => `<div class="chat-bubble ${m.mine ? 'mine' : ''}">${escapeHtml(m.text)}<small>${escapeHtml(m.time || 'now')}</small></div>`).join('')}`;
    $('#chatHeading').innerHTML = `${avatar(current.name, current.color)}<span><b>${current.name}</b><small>● &nbsp;Online</small></span>`;
    $('#chatMessages').scrollTop = $('#chatMessages').scrollHeight;
  }
  function renderCommunity() {
    $('#view-community').innerHTML = `<div class="page-heading"><div><div class="eyebrow-dark">BETTER, TOGETHER</div><h1>Community</h1><p>Ask a question, share a win, or find someone to study with.</p></div><div class="heading-actions"><button class="button button-secondary" data-action="new-message">✉ Start a chat</button></div></div><div class="community-layout"><div><div class="composer">${avatar(data.user?.name || 'Student')}<div class="composer-main"><textarea id="postInput" placeholder="What’s on your mind? Share a question, a useful tip, or a small win..."></textarea><div class="composer-bottom"><span>✳ &nbsp;Your study circle is here for it</span><button class="button button-primary" data-action="publish-post">Share with community →</button></div></div></div><div id="postFeed">${renderPosts()}</div></div><aside class="community-side"><div class="section-card"><div class="section-header"><h3>Your study circle</h3><span class="eyebrow-dark">3 ONLINE</span></div>${people.map(p => `<div class="people-row">${avatar(p.name, p.color)}<span class="person-copy"><b>${p.name}</b><small>${p.name === 'Meera Joshi' ? 'Statistics · online' : 'IITAN student'}</small></span><button class="text-button" data-action="message-person" data-name="${p.name}">Chat</button></div>`).join('')}</div><div class="section-card"><div class="section-header"><h3>Popular this week</h3></div><div class="topic-row"><span># Probability study group</span><small>24 posts</small></div><div class="topic-row"><span># Python practice</span><small>18 posts</small></div><div class="topic-row"><span># Study routines</span><small>12 posts</small></div><div class="topic-row"><span># Calculus help</span><small>9 posts</small></div></div><div class="section-card"><div class="section-header"><h3>Be a good study buddy</h3></div><p style="font-size:10px;line-height:1.65;color:#849087;margin:0">A thoughtful question or a shared explanation can make someone’s whole week. Keep it kind, keep it curious.</p></div></aside></div><div class="section-card" style="margin-top:14px;padding:0;overflow:hidden"><div class="chat-panel"><aside class="chat-list"><div class="chat-list-head"><h3>Messages</h3><input class="chat-search" placeholder="Search conversations" /></div><div id="chatList"></div></aside><section class="chat-main"><div class="chat-top" id="chatHeading"></div><div class="chat-messages" id="chatMessages"></div><form class="chat-compose" id="chatForm"><input id="chatInput" placeholder="Write a message..." autocomplete="off" /><button class="button button-primary" type="submit">Send ↗</button></form></section></div></div>`;
    renderChats();
  }
  function renderReels() {
    const v = data.videos[0];
    const side = data.videos.slice(1).map((video, i) => `<article class="video-card" data-action="play-video" data-id="${video.id}"><div class="video-thumb ${i === 0 ? 'v2' : 'v3'}">${escapeHtml(video.symbol || '✳')}</div><div class="video-info"><b>${escapeHtml(video.title)}</b><small>${escapeHtml(video.creator)} · ${video.likes || 0} likes</small></div></article>`).join('');
    $('#view-reels').innerHTML = `<div class="page-heading"><div><div class="eyebrow-dark">QUICK IDEAS, SHARED</div><h1>Reels & videos</h1><p>Little lessons from your community, made for the in-between moments.</p></div><div class="heading-actions"><button class="button button-primary" data-action="upload-video">＋ Share a video</button></div></div><div class="reels-layout"><div class="reel-stage"><div class="reel-gradient"></div><div class="reel-visual">${escapeHtml(v?.symbol || '✳')}</div><div class="reel-content"><span class="subject-tag">${escapeHtml(v?.subject || 'Study tips')}</span><h2>${escapeHtml(v?.title || 'Share a little lesson')}</h2><p>${escapeHtml(v?.description || '')} · by ${escapeHtml(v?.creator || '')}</p></div><div class="reel-actions"><button class="reel-action" data-action="like-video" data-id="${v?.id}">♡<small>${v?.likes || 0}</small></button><button class="reel-action" data-action="share-video" data-id="${v?.id}">↗<small>Share</small></button><button class="reel-action" data-action="next-video">⌄<small>Next</small></button></div></div><aside class="reel-sidebar"><div class="section-card"><div class="section-header"><h3>Up next</h3><span class="eyebrow-dark">FROM IITAN</span></div>${side || '<p style="font-size:10px;color:#89948b">More videos are on the way.</p>'}</div><div class="section-card"><h3 style="font-size:12px;margin:0 0 8px">Have something to share?</h3><p style="font-size:10px;color:#879188;line-height:1.6">A 30-second explanation can help someone understand a whole new concept.</p><button class="button button-secondary" style="font-size:9px" data-action="upload-video">Upload a video →</button></div></aside></div>`;
  }
  function renderAll() {
    authRender(); if (!data.user) return;
    renderHome(); renderQuizzes(); renderNotes(); renderAssignments(); renderCommunity(); renderReels();
    $('#quizNavCount').textContent = data.quizzes.length; $('#assignmentNavCount').textContent = data.assignments.filter(a => a.status !== 'Submitted').length; $('#streakCount').textContent = `${data.streak || 1} day${data.streak === 1 ? '' : 's'} streak`;
    go(activeView);
  }
  function modal(title, subtitle, body, options = {}) {
    $('#modalRoot').innerHTML = `<div class="modal-backdrop" data-action="backdrop-close"><div class="modal ${options.wide ? 'modal-wide' : ''}" role="dialog" aria-modal="true" aria-label="${escapeHtml(title)}"><div class="modal-header"><div><h2>${escapeHtml(title)}</h2><p>${escapeHtml(subtitle || '')}</p></div><button class="modal-close" data-action="close-modal" aria-label="Close">×</button></div>${body}</div></div>`;
  }
  function closeModal() { $('#modalRoot').innerHTML = ''; currentQuiz = null; selectedFiles = {}; }
  function openQuizCreate() {
    modal('Create a practice quiz', 'Make a few questions to help someone else learn.', `<form id="quizCreateForm"><div class="modal-form-grid"><div class="field-group full"><label>Quiz title</label><input name="title" required maxlength="75" placeholder="e.g. Introduction to derivatives" /></div><div class="field-group"><label>Subject</label><select name="subject">${subjects.map(s => `<option>${s}</option>`).join('')}</select></div><div class="field-group"><label>Difficulty</label><select name="difficulty"><option>Easy</option><option selected>Medium</option><option>Hard</option></select></div><div class="field-group full"><label>Short description</label><textarea class="form-control" name="description" rows="2" placeholder="What will students practice?"></textarea></div></div><div class="question-builder"><h4>Question 1</h4><div class="field-group"><input name="prompt" required placeholder="Write your question" /></div><div class="option-grid"><input name="option0" required placeholder="Option A" /><input name="option1" required placeholder="Option B" /><input name="option2" required placeholder="Option C" /><input name="option3" required placeholder="Option D" /></div><div class="field-group" style="margin:11px 0 0"><label>Correct answer</label><select name="answer"><option value="0">Option A</option><option value="1">Option B</option><option value="2">Option C</option><option value="3">Option D</option></select></div></div><div class="modal-actions"><button type="button" class="button button-plain" data-action="close-modal">Cancel</button><button class="button button-primary">Create quiz</button></div></form>`);
  }
  function startQuiz(id) {
    const quiz = data.quizzes.find(q => q.id === id); if (!quiz) return;
    currentQuiz = quiz;
    const questions = quiz.questions.map((q, i) => `<div class="quiz-question"><h3>${i + 1}. ${escapeHtml(q.prompt)}</h3>${q.options.map((o, j) => `<label class="answer-option"><input type="radio" name="answer-${i}" value="${j}" required />${escapeHtml(o)}</label>`).join('')}</div>`).join('');
    modal(quiz.title, `${quiz.subject} · ${quiz.questions.length} questions · choose one answer for each`, `<form id="takeQuizForm"><div>${questions}</div><div class="modal-actions"><button type="button" class="button button-plain" data-action="close-modal">Not now</button><button class="button button-primary">Check my answers →</button></div></form>`, { wide: true });
  }
  function openNoteForm() {
    modal('Upload study notes', 'Share a resource that made something click for you.', `<form id="noteForm"><div class="modal-form-grid"><div class="field-group full"><label>Resource title</label><input name="title" required placeholder="e.g. Week 2 linear algebra notes" /></div><div class="field-group"><label>Subject</label><select name="subject">${subjects.map(s => `<option>${s}</option>`).join('')}</select></div><div class="field-group"><label>File (PDF, document, or image)</label><input type="file" name="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.txt,.png,.jpg,.jpeg" /></div><div class="field-group full"><label>What’s inside?</label><textarea class="form-control" name="description" rows="3" placeholder="A quick description helps other students find the right resource."></textarea></div></div><div class="modal-actions"><button type="button" class="button button-plain" data-action="close-modal">Cancel</button><button class="button button-primary">Add to library →</button></div></form>`);
  }
  function openAssignmentForm() {
    modal('Add an assignment', 'Keep a deadline or practice task in your hub.', `<form id="assignmentForm"><div class="modal-form-grid"><div class="field-group full"><label>Assignment title</label><input name="title" required placeholder="e.g. Week 5 problem set" /></div><div class="field-group"><label>Subject</label><select name="subject">${subjects.map(s => `<option>${s}</option>`).join('')}</select></div><div class="field-group"><label>Due date</label><input name="due" type="date" required value="${new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10)}" /></div><div class="field-group full"><label>Details</label><textarea class="form-control" name="description" rows="3" placeholder="What do you need to complete?"></textarea></div></div><div class="modal-actions"><button type="button" class="button button-plain" data-action="close-modal">Cancel</button><button class="button button-primary">Add assignment</button></div></form>`);
  }
  function submitAssignment(id) {
    const a = data.assignments.find(x => x.id === id); if (!a) return;
    modal('Submit your work', a.title, `<form id="submissionForm" data-id="${a.id}"><div class="field-group"><label>Optional note for your submission</label><textarea class="form-control" name="note" rows="3" placeholder="Anything you’d like to remember about this work?"></textarea></div><div class="upload-zone"><strong>Choose your completed work</strong>PDF, document, image, or code file<input type="file" name="file" required /></div><div class="modal-actions"><button type="button" class="button button-plain" data-action="close-modal">Cancel</button><button class="button button-primary">Submit assignment →</button></div></form>`);
  }
  function uploadVideoForm() {
    modal('Share a study video', 'Keep it short, helpful, and made by you.', `<form id="videoForm"><div class="modal-form-grid"><div class="field-group full"><label>Video title</label><input name="title" required placeholder="e.g. A quick trick for derivatives" /></div><div class="field-group"><label>Subject</label><select name="subject">${[...subjects, 'Study tips'].map(s => `<option>${s}</option>`).join('')}</select></div><div class="field-group"><label>Video file</label><input name="file" type="file" accept="video/*" required /></div><div class="field-group full"><label>What will someone learn?</label><textarea class="form-control" name="description" rows="2" placeholder="A sentence about your video"></textarea></div></div><div class="upload-zone"><strong>Videos stay in your browser for this demo</strong>Choose a video file to add it to your local hub.</div><div class="modal-actions"><button type="button" class="button button-plain" data-action="close-modal">Cancel</button><button class="button button-primary">Share video →</button></div></form>`);
  }
  function showFile(file, callback) { if (!file) return callback('', ''); const reader = new FileReader(); reader.onload = () => callback(reader.result, file.name); reader.onerror = () => { toast('That file could not be read. Try another one.'); }; reader.readAsDataURL(file); }
  function openResource(n) {
    if (n.fileData) { const link = document.createElement('a'); link.href = n.fileData; link.download = n.fileName || n.title; link.target = '_blank'; link.click(); }
    else toast(`${n.fileName || n.title} — resource details opened`);
  }
  function shareText(text) { if (navigator.share) navigator.share({ title: 'BS Degree Hub IITAN', text }).catch(() => {}); else if (navigator.clipboard) navigator.clipboard.writeText(text).then(() => toast('Copied to clipboard')).catch(() => toast('Ready to share')); else toast('Ready to share'); }
  function act(action, element) {
    const id = element.dataset.id;
    if (action === 'create-quiz') return openQuizCreate();
    if (action === 'start-quiz') return startQuiz(id);
    if (action === 'add-note') return openNoteForm();
    if (action === 'create-assignment') return openAssignmentForm();
    if (action === 'submit-assignment') return submitAssignment(id);
    if (action === 'upload-video') return uploadVideoForm();
    if (action === 'close-modal') return closeModal();
    if (action === 'backdrop-close' && element === event.target) return closeModal();
    if (action === 'quiz-filter') { activeQuizFilter = element.dataset.value; renderQuizzes(); return; }
    if (action === 'note-filter') { activeNoteFilter = element.dataset.value; renderNotes(); return; }
    if (action === 'open-note') { const n = data.notes.find(x => x.id === id); if (n) openResource(n); return; }
    if (action === 'view-submission') { const a = data.assignments.find(x => x.id === id); return toast(a?.fileName ? `Submitted: ${a.fileName}` : 'Submission recorded'); }
    if (action === 'like-post') { const p = data.posts.find(x => x.id === id); if (p) { p.liked = !p.liked; p.likes += p.liked ? 1 : -1; persist(); } return; }
    if (action === 'comment-post') { const p = data.posts.find(x => x.id === id); if (!p) return; const text = prompt('Add a thoughtful comment:'); if (text?.trim()) { p.comments ||= []; p.comments.push({ author: data.user.name, text: text.trim() }); persist(true, 'Comment added'); } return; }
    if (action === 'share-post') { const p = data.posts.find(x => x.id === id); if (p) shareText(p.body); return; }
    if (action === 'publish-post') { const input = $('#postInput'); const body = input?.value.trim(); if (!body) return toast('Write a little something before sharing.'); data.posts.unshift({ id: `p${Date.now()}`, author: data.user.name, body, subject: 'IITAN student', attachment: '', createdAt: new Date().toISOString(), likes: 0, liked: false, comments: [] }); persist(true, 'Your post is up — thanks for sharing!'); return; }
    if (action === 'message-person') { activeChat = element.dataset.name; go('community'); renderChats(); $('#chatInput')?.focus(); return; }
    if (action === 'new-message') { activeChat = people[0].name; go('community'); $('#chatInput')?.focus(); return; }
    if (action === 'select-chat') { activeChat = element.dataset.name; renderChats(); return; }
    if (action === 'like-video') { const video = data.videos.find(x => x.id === id); if (video) { video.likes = (video.likes || 0) + 1; persist(true, 'Video liked'); } return; }
    if (action === 'share-video') { const video = data.videos.find(x => x.id === id); if (video) shareText(video.title); return; }
    if (action === 'next-video') { if (data.videos.length > 1) { data.videos.push(data.videos.shift()); persist(); } return; }
    if (action === 'play-video') { const i = data.videos.findIndex(x => x.id === id); if (i > 0) { const [v] = data.videos.splice(i, 1); data.videos.unshift(v); persist(); } return; }
    if (action === 'logout') { data.user = null; save(); authRender(); return; }
    if (action === 'edit-profile') { openProfile(); return; }
  }
  function openProfile() {
    modal('Your profile', 'Update how you show up in your study hub.', `<form id="profileForm"><div class="field-group"><label>Your name</label><input name="name" value="${escapeHtml(data.user.name)}" required /></div><div class="field-group"><label>College email</label><input name="email" type="email" value="${escapeHtml(data.user.email)}" required /></div><div class="modal-actions"><button type="button" class="button button-danger" data-action="logout">Sign out</button><span style="flex:1"></span><button type="button" class="button button-plain" data-action="close-modal">Cancel</button><button class="button button-primary">Save profile</button></div></form>`);
  }
  document.addEventListener('click', event => {
    const goButton = event.target.closest('[data-go]'); if (goButton) { go(goButton.dataset.go); return; }
    const nav = event.target.closest('.nav-item'); if (nav) { go(nav.dataset.view); return; }
    const actionElement = event.target.closest('[data-action]'); if (actionElement) { act(actionElement.dataset.action, actionElement); return; }
    if (event.target.closest('#profileButton')) openProfile();
    if (event.target.closest('#notificationButton')) toast('You’re all caught up.');
  });
  document.addEventListener('input', event => {
    if (event.target.id === 'quizSearch') { const pos = event.target.selectionStart; renderQuizzes(); const input = $('#quizSearch'); input.focus(); input.setSelectionRange(pos, pos); }
    if (event.target.id === 'noteSearch') { const pos = event.target.selectionStart; renderNotes(); const input = $('#noteSearch'); input.focus(); input.setSelectionRange(pos, pos); }
  });
  document.addEventListener('submit', event => {
    const form = event.target; event.preventDefault();
    if (form.id === 'authForm') {
      const email = $('#authEmail').value.trim().toLowerCase(); const password = $('#authPassword').value;
      if (authMode === 'signup') { const name = $('#authName').value.trim(); if (!name) return; data.user = { name, email }; data.streak = Math.max(data.streak || 1, 1); save(); authRender(); renderAll(); toast(`Welcome to the hub, ${name.split(' ')[0]}!`); }
      else { if (!email || password.length < 6) { $('#authError').textContent = 'Please enter a valid email and a password with at least 6 characters.'; return; } const savedUsers = JSON.parse(localStorage.getItem(`${STORE}-users`) || '{}'); const record = savedUsers[email]; if (record && record.password !== password) { $('#authError').textContent = 'That password doesn’t match this account. Try again.'; return; } data.user = record?.user || { name: email.split('@')[0].replace(/[._-]/g, ' ').replace(/\b\w/g, c => c.toUpperCase()), email }; save(); authRender(); renderAll(); toast('You’re signed in. Welcome back!'); }
    }
    if (form.id === 'quizCreateForm') {
      const f = new FormData(form); const questions = [{ prompt: f.get('prompt').trim(), options: [0,1,2,3].map(i => f.get(`option${i}`).trim()), answer: Number(f.get('answer')) }];
      data.quizzes.unshift({ id: `q${Date.now()}`, title: f.get('title').trim(), subject: f.get('subject'), difficulty: f.get('difficulty'), description: f.get('description').trim() || 'A student-created practice quiz.', creator: data.user.name, questions, attempts: 0, createdAt: new Date().toISOString() }); closeModal(); persist(true, 'Your quiz is ready for the community.'); go('quizzes');
    }
    if (form.id === 'takeQuizForm') {
      const quiz = currentQuiz; if (!quiz) return; const f = new FormData(form); let score = 0; quiz.questions.forEach((q, i) => { if (Number(f.get(`answer-${i}`)) === q.answer) score++; }); quiz.attempts = (quiz.attempts || 0) + 1; data.quizResults.unshift({ quizId: quiz.id, title: quiz.title, score, total: quiz.questions.length, date: new Date().toISOString() }); data.streak = (data.streak || 1) + 1; save();
      const detail = quiz.questions.map((q, i) => { const chosen = Number(f.get(`answer-${i}`)); return `<div class="quiz-question"><h3>${i + 1}. ${escapeHtml(q.prompt)}</h3><p style="font-size:10px;color:${chosen === q.answer ? '#4c8758' : '#b45f4d'};margin:0">${chosen === q.answer ? '✓ Correct' : `Your answer: ${escapeHtml(q.options[chosen])}`} · Correct answer: <b>${escapeHtml(q.options[q.answer])}</b></p></div>`; }).join('');
      currentQuiz = null; modal('Nice work — here’s your result', quiz.title, `<div class="result-banner"><strong>${score} / ${quiz.questions.length}</strong><span>${Math.round(score / quiz.questions.length * 100)}% correct · keep practicing, you’re making progress.</span></div><div>${detail}</div><div class="modal-actions"><button class="button button-primary" data-action="close-modal">Done</button></div>`, { wide: true }); renderAll();
    }
    if (form.id === 'noteForm') {
      const f = new FormData(form), file = f.get('file'); const add = (fileData, fileName) => { data.notes.unshift({ id: `n${Date.now()}`, title: f.get('title').trim(), subject: f.get('subject'), description: f.get('description').trim(), creator: data.user.name, fileName: fileName || 'Study notes', fileData, cover: ['blue', 'yellow', 'pink', ''][data.notes.length % 4], createdAt: new Date().toISOString() }); closeModal(); persist(true, 'Notes added to the library.'); go('notes'); }; if (file?.size > 3_000_000) return toast('For this browser demo, files need to be under 3 MB.'); showFile(file, add);
    }
    if (form.id === 'assignmentForm') {
      const f = new FormData(form); data.assignments.unshift({ id: `a${Date.now()}`, title: f.get('title').trim(), subject: f.get('subject'), due: new Date(`${f.get('due')}T12:00:00`).toISOString(), description: f.get('description').trim(), status: 'Open', fileName: '', fileData: '', creator: data.user.name }); closeModal(); persist(true, 'Assignment added to your list.'); go('assignments');
    }
    if (form.id === 'submissionForm') {
      const id = form.dataset.id, a = data.assignments.find(x => x.id === id), file = new FormData(form).get('file'); if (!file) return; if (file.size > 3_000_000) return toast('For this browser demo, files need to be under 3 MB.'); showFile(file, (fileData, fileName) => { a.status = 'Submitted'; a.fileName = fileName; a.fileData = fileData; a.submittedAt = new Date().toISOString(); closeModal(); persist(true, 'Assignment submitted — nicely done!'); go('assignments'); });
    }
    if (form.id === 'videoForm') {
      const f = new FormData(form), file = f.get('file'); if (file?.size > 3_000_000) return toast('For this browser demo, files need to be under 3 MB.'); showFile(file, (fileData, fileName) => { data.videos.unshift({ id: `v${Date.now()}`, title: f.get('title').trim(), subject: f.get('subject'), creator: data.user.name, description: f.get('description').trim(), symbol: '▶', likes: 0, createdAt: new Date().toISOString(), fileName, fileData }); closeModal(); persist(true, 'Your video is now in the hub.'); go('reels'); });
    }
    if (form.id === 'chatForm') {
      const input = $('#chatInput'), text = input.value.trim(); if (!text) return; data.chats[activeChat] ||= [{ text: 'Hey! How is your week going?', mine: false, time: '10:12' }]; data.chats[activeChat].push({ text, mine: true, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }); const reply = activeChat === 'Meera Joshi' ? 'That makes sense, thank you!' : 'Thanks for sharing! I’ll take a look.'; data.chats[activeChat].push({ text: reply, mine: false, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }); save(); input.value = ''; renderChats();
    }
    if (form.id === 'profileForm') { const f = new FormData(form); data.user.name = f.get('name').trim(); data.user.email = f.get('email').trim(); const users = JSON.parse(localStorage.getItem(`${STORE}-users`) || '{}'); if (users[data.user.email]) users[data.user.email].user = data.user; localStorage.setItem(`${STORE}-users`, JSON.stringify(users)); closeModal(); persist(true, 'Profile updated.'); }
  });
  $('#authToggle').addEventListener('click', () => setAuthMode(authMode === 'signin' ? 'signup' : 'signin'));
  $('#forgotButton').addEventListener('click', () => toast('If you signed up here, your account is saved in this browser.'));
  $('#mobileMenu').addEventListener('click', () => $('#sidebar').classList.toggle('open'));
  $('#globalSearch').addEventListener('keydown', event => { if (event.key === 'Enter') { const q = event.target.value.trim(); if (!q) return; activeQuizFilter = 'All subjects'; activeNoteFilter = 'All subjects'; go('quizzes'); $('#quizSearch').value = q; renderQuizzes(); } });
  document.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); $('#globalSearch').focus(); } });
  // Keep demo credentials available only in this browser; real authentication requires a backend.
  const originalSubmit = $('#authForm');
  originalSubmit.addEventListener('submit', () => {
    if (authMode === 'signup') setTimeout(() => { const email = data.user?.email; if (email) { const users = JSON.parse(localStorage.getItem(`${STORE}-users`) || '{}'); users[email] = { user: data.user, password: $('#authPassword').value }; localStorage.setItem(`${STORE}-users`, JSON.stringify(users)); } }, 0);
  });
  renderAll();
})();
